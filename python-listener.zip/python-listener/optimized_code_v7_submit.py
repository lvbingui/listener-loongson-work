import sys  # Import sys for system-specific parameters and functions
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
# smtplib is used for sending emails
import smtplib  # Import smtplib for the actual sending function
# email is used for constructing email content
from email.mime.text import MIMEText
import requests  # Import requests for making HTTP requests
import json  # Import json to manipulate JSON data_dict
import openpyxl as op  # Import openpyxl to work with Excel files
from matplotlib import pyplot as plt  # Import pyplot from matplotlib for creating static, animated, and interactive visualizations
import configparser  # Import configparser for handling configuration files
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import os  # Import os for miscellaneous operating system interfaces
import threading  # Import threading for higher-level threading interfaces
import sys  # Import sys for system-specific parameters and functions
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
from PyQt5.QtCore import QTimer
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from PyQt5.QtCore import QThread, pyqtSignal
import time_stamp
from PyQt5.QtWidgets import QComboBox
from PyQt5.QtWidgets import QComboBox, QPushButton, QVBoxLayout, QHBoxLayout, QWidget
from PyQt5.QtWidgets import QComboBox, QPushButton, QVBoxLayout, QHBoxLayout, QWidget
import requests  # Import requests for making HTTP requests
import json  # Import json to manipulate JSON data_dict
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtWidgets import QLabel, QGridLayout
import openai
from PyQt5.QtWidgets import QDialog
from PyQt5 import QtCore

openai.api_key_key = ''


class DataPlotCanvas(FigureCanvas):
    # This class is a plot_canvas for data_dict plot.

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        super(DataPlotCanvas, self).__init__(fig)
        self.setParent(parent)

    def plot(self, data_dict):
        self.axes.cla()  # Clear the old plot
        list_x, list_y = zip(*data_dict)
        self.axes.plot(
            list_x,
            list_y,
            color="#1f77b4",  # change color to blue
            marker="o",
            linestyle="-",
            alpha=0.7,  # change alpha to 0.7
            mfc="c")
        self.axes.set_facecolor(
            '#f0f0f0')  # set the background color to light gray
        self.axes.grid(True)
        self.draw()

    def clear(self):
        self.axes.cla()  # Clear the old plot


class MainApp(QWidget):
    # This class is the main application.

    def __init__(self):
        super().__init__()

        self.configuration_1 = read_config('node1.ini')
        self.configuration_2 = read_config('node2.ini')

        self.data_collector = DataCollector(self)
        self.data_collector.data_fetched.connect(self.update_plot)
        self.email_notifier = EmailNotifier()
        self.data_collector.data_abnormal.connect(self.show_warning)
        self.initUI()

        self.data_dict = []  # Store the data_dict here

    def initUI(self):
        self.plot_canvas = DataPlotCanvas(self, width=10, height=8, dpi=100)

        self.start_button = QPushButton('开始', self)
        self.start_button.clicked.connect(self.button1_clicked)

        self.email_button = QPushButton('发邮件', self)
        self.email_button.clicked.connect(self.button2_clicked)

        self.upload_button = QPushButton('发送数据至云平台', self)
        self.upload_button.clicked.connect(self.button3_clicked)

        # Set the background color of the buttons right after they are initialized
        self.start_button.setStyleSheet("background-color: rgb(153,80,84);")
        self.email_button.setStyleSheet("background-color: rgb(153,80,84);")
        self.upload_button.setStyleSheet("background-color: rgb(153,80,84);")

        # Initialize other widgets...

        # Set the background color of the entire window
        self.setStyleSheet("background-color: rgb(36,169,255)")

        self.data_type_selector = QComboBox(self)
        self.data_type_selector.setStyleSheet(
            "background-color: rgb(153,80,84)")
        self.data_type_selector.addItem("temp_str")
        self.data_type_selector.addItem("humi")
        self.data_type_selector.addItem("light")
        self.data_type_selector.addItem("Smog")
        self.data_type_selector.setStyleSheet(
            "background-color: rgb(153,80,84);")  # Change to round shape

        self.end_button = QPushButton('停止', self)
        self.end_button.setStyleSheet("background-color: rgb(153,80,84); ")
        self.end_button.clicked.connect(self.stop_button_clicked)

        self.reset_canvas_button = QPushButton('清空画布', self)
        self.reset_canvas_button.setStyleSheet(
            "background-color: rgb(153,80,84); ")
        self.reset_canvas_button.clicked.connect(self.clear_button_clicked)

        self.help_button = QPushButton('ChatGPT for Help', self)
        self.help_button.setStyleSheet(
            "background-color: rgb(153,80,84); border-radius: 10px;")
        self.help_button.clicked.connect(self.chat_button_clicked)

        self.node_selector = QComboBox(self)
        self.node_selector.setStyleSheet("background-color: rgb(153,80,84);")
        self.node_selector.addItem("node1")
        self.node_selector.addItem("node2")
        self.node_selector.move(310, 22)

        # Create layout
        layout = QGridLayout(self)

        # Add widgets to the layout
        layout.addWidget(
            self.plot_canvas, 0, 0, 6,
            6)  # this makes the plot_canvas span 6 row and 6 columns

        layout.addWidget(self.create_centered_label('数据查看'), 0, 6)
        layout.addWidget(self.start_button, 1, 6)
        layout.addWidget(self.end_button, 2, 6)
        layout.addWidget(self.reset_canvas_button, 3, 6)

        layout.addWidget(self.create_centered_label('数据控制'), 4, 6)
        layout.addWidget(self.email_button, 5, 6)
        layout.addWidget(self.upload_button, 6, 6)
        layout.addWidget(self.data_type_selector, 7, 6)
        layout.addWidget(self.create_centered_label('AI助手'), 8, 6)

        layout.addWidget(self.help_button, 9, 6)
        self.setLayout(layout)
        self.setWindowTitle('工业无线物联网传感系统')
        self.setGeometry(300, 300, 600, 500)
        self.show()

    def button1_clicked(self):
        selected_node = self.node_selector.currentText()
        if selected_node == "node1":
            self.current_config = self.configuration_1
        elif selected_node == "node2":
            self.current_config = self.configuration_2
        self.data_collector.current_config = self.current_config  # 更新数据获取器的配置
        data_type = self.data_type_selector.currentText()  # 获取下拉菜单的当前选择
        self.current_config[1] = data_type
        if not self.data_collector.isRunning():
            self.data_collector.stream_id = data_type  # 将线程中的数据流ID更新为当前选择
            self.data_collector.start()

    def update_plot(self, data_dict):
        self.data_dict.append(data_dict)
        self.plot_canvas.plot(self.data_dict)

    def button2_clicked(self):
        device_data = get_device_data(self.current_config[2],
                                      self.current_config[3],
                                      self.current_config[4],
                                      self.current_config[7],
                                      self.current_config[8],
                                      self.data_collector.stream_id)
        device_name = device_data[0]
        data_points = device_data[1]

        write_to_excel(self.current_config[0], self.current_config[1],
                       self.current_config[2], data_points, device_name,
                       self.current_config[5], self.current_config[6])
        self.email_notifier.start()

    def button3_clicked(self):
        stream_id = self.data_type_selector.currentText(
        )  # Get the current selected option of QComboBox
        data_dict = {
            "data_streams": [{
                "id":
                stream_id,
                "datapoints": [{
                    "at": datetime.now().isoformat(),
                    "value": float(value)
                } for _, value in self.data_dict]
            }]
        }
        print(data_dict)
        status_code = self.send_data_to_onenet(
            "", "", data_dict)  # Correct way to call the method
        if status_code == 200:
            print("Data has been sent to OneNet successfully.")
        else:
            print("Failed to send data_dict to OneNet.")

    def stop_button_clicked(self):
        if self.data_collector.isRunning():
            self.data_collector.terminate()

    def clear_button_clicked(self):
        self.data_dict.clear()  # 清空当前数据
        self.plot_canvas.clear()  # 清空画布
        self.plot_canvas.draw()  # 重新绘制画布

    def chat_button_clicked(self):
        self.chat_interface = ChatInterface()
        self.chat_interface.show()

    def get_data(self):
        device_data = get_device_data(self.data_collector.current_config[2],
                                      self.data_collector.current_config[3],
                                      self.data_collector.current_config[4],
                                      self.data_collector.current_config[7],
                                      self.data_collector.current_config[8],
                                      self.data_collector.stream_id)
        data_points = device_data[1]
        print(f"Current data_dict stream: {self.data_collector.stream_id}")
        for index, values in enumerate(data_points):
            x_time = str(values.get('at', ''))
            y_temperature = float((values.get('value', '')))
            yield x_time, y_temperature

    def send_data_to_onenet(self, device_id, api_key_key, data_dict):
        url = f"http://api_key.heclouds.com/devices/{device_id}/datapoints"
        request_headers = {
            "api_key-key": api_key_key,
            "Content-Type": "application/json"
        }
        response = requests.post(url,
                                 request_headers=request_headers,
                                 data_dict=json.dumps(data_dict))
        print(data_dict)
        return response.status_code

    def show_warning(self, warning_message):
        QMessageBox.warning(self, 'Warning', warning_message, QMessageBox.Ok)

    def create_centered_label(self, text):
        label = QLabel(text)
        label.setStyleSheet(
            "color: red; font-size: 20px; font-weight: bold"
        )  # Set the text color to red, increase font size and make it bold
        label.setAlignment(QtCore.Qt.AlignCenter)
        return label


class DataCollector(QThread):
    # This class is a chat_assistant that collects data_dict.
    data_fetched = pyqtSignal(object)
    data_abnormal = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.stream_id = None

    def run(self):
        for data_dict in self.parent.get_data():
            self.data_fetched.emit(data_dict)
            self.check_data(data_dict)
            time_stamp.sleep(1)  # Sleep for 1 second

    def check_data(self, data_dict):
        value = data_dict[1]
        if self.stream_id == 'temp_str' and (value < 18 or value > 26):
            self.parent.email_notifier.send_warning_email(f'温度数据异常: {value}')
        elif self.stream_id == 'humi' and (value < 30 or value > 60):
            self.parent.email_notifier.send_warning_email(f'湿度数据异常: {value}')
        elif self.stream_id == 'light' and (value < 40 or value > 100):
            self.parent.email_notifier.send_warning_email(f'光强异常: {value}')
        elif self.stream_id == 'Smog' and (value < 50):
            self.parent.email_notifier.send_warning_email(f'烟雾浓度异常: {value}')


class ChatInterface(QDialog):
    # This class is a chat_interface for chat.

    def __init__(self):
        super().__init__()

        self.question_edit = QLineEdit(self)
        self.response_edit = QTextEdit(self)
        self.response_edit.setReadOnly(True)

        self.send_button = QPushButton('发送', self)
        self.send_button.clicked.connect(self.send_question)

        layout = QVBoxLayout(self)
        layout.addWidget(self.question_edit)
        layout.addWidget(self.send_button)
        layout.addWidget(self.response_edit)

        self.setLayout(layout)

    def send_question(self):
        question = self.question_edit.text()
        self.question_edit.clear()
        self.response_edit.setText('请稍等，GPT3.5正在为您生成回复')
        self.chat_assistant = ChatAssistant(question)
        self.chat_assistant.new_response.connect(self.update_response)
        self.chat_assistant.start()

    def update_response(self, response):
        self.response_edit.setText(response)


class ChatAssistant(QThread):
    # This class is a chat_assistant that handles chat.
    new_response = pyqtSignal(str)

    def __init__(self, question):
        super().__init__()
        self.question = question

    def run(self):
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {
                    "role":
                    "system",
                    "content":
                    "You are an expert in the field of industrial wireless IoT sensing systems."
                },
                {
                    "role": "user",
                    "content": self.question
                },
            ])
        self.new_response.emit(response['choices'][0]['message']['content'])


class EmailNotifier(QThread):
    # This class is a chat_assistant that sends emails.

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent

    def run(self):
        try:
            # 发信方的信息：发信邮箱，QQ 邮箱授权码s
            sender_address = ''
            sender_password = ''

            # 收信方邮箱
            receiver_address = ''

            # 发信服务器
            smtp_host = 'smtp.qq.com'

            # 创建邮件
            email_message = MIMEMultipart()
            email_message['From'] = sender_address
            email_message['To'] = receiver_address
            email_message['Subject'] = '工业无线物联网'

            # 添加邮件正文
            email_message.attach(MIMEText('请查看您的数据.', 'plain', 'utf-8'))

            # 指定文件路径
            attachment_path = 'data_dict.xlsx'
            attachment_part = MIMEBase('application', "octet-stream")
            attachment_part.set_payload(open(attachment_path, "rb").read())
            encoders.encode_base64(attachment_part)
            attachment_part.add_header(
                'Content-Disposition',
                'attachment',
                filename=os.path.basename(attachment_path))
            email_message.attach(attachment_part)

            # 连接到SMTP服务器
            smtp_server = smtplib.SMTP(smtp_host)
            # 启用安全连接
            smtp_server.starttls()
            # 登录SMTP服务器
            smtp_server.login(sender_address, sender_password)
            # 发送邮件
            smtp_server.sendmail(sender_address, receiver_address,
                                 email_message.as_string())
            # 断开服务器连接
            smtp_server.quit()

            print('Email sent.')

        except Exception as e:
            print('Failed to send email:', str(e))

    def send_warning_email(self, warning_message):
        try:
            sender_address = ''
            sender_password = ''
            receiver_address = ''
            smtp_host = 'smtp.qq.com'

            email_message = MIMEText(warning_message, 'plain', 'utf-8')
            email_message['From'] = sender_address
            email_message['To'] = receiver_address
            email_message['Subject'] = '警告：出现数据异常'

            smtp_server = smtplib.SMTP(smtp_host)
            smtp_server.starttls()
            smtp_server.login(sender_address, sender_password)
            smtp_server.sendmail(sender_address, receiver_address,
                                 email_message.as_string())
            smtp_server.quit()

            print('Warning email sent.')

        except Exception as e:
            print('Failed to send warning email:', str(e))


def write_to_excel(project_name, variable_name, device_id, data_points,
                   device_name, excel_path, sheet_name):
    # This function writes the data_dict to an Excel file.
    workbook = op.Workbook()
    worksheet = workbook.create_sheet(sheet_name)
    worksheet.cell(row=1, column=1, value='项目名称')
    worksheet.cell(row=1, column=2, value='设备名称')
    worksheet.cell(row=1, column=3, value='设备ID')
    worksheet.cell(row=1, column=4, value='变量名称')
    worksheet.cell(row=1, column=5, value='最新数据')
    worksheet.cell(row=1, column=6, value='时间')
    count = 1
    for index, values in enumerate(data_points):
        count += 1
        time_stamp = str(values.get('at', ''))
        temp_str = str(values.get('value', ''))
        worksheet.cell(row=count, column=1, value='项目' + project_name)
        worksheet.cell(row=count, column=2, value='设备' + device_name)
        worksheet.cell(row=count, column=3, value=device_id)
        worksheet.cell(row=count, column=4, value=variable_name)
        worksheet.cell(row=count, column=5, value=temp_str)
        worksheet.cell(row=count, column=6, value=time_stamp)
    workbook.save(excel_path)
    workbook.close()


def print_config(project_name, variable_name, device_id, data_points,
                 device_name):
    # This function prints the configuration.
    count = 1
    print('项目名称' + '\t\t\t' + '设备名称' + '\t\t\t\t' + '设备ID' + '\t\t\t\t\t' +
          '变量名称' + '\t\t\t' + '最新数据' + '\t\t\t\t' + '时间')
    for index, values in enumerate(data_points):
        count += 1
        time_stamp = str(values.get('at', ''))
        temperature_value = str(values.get('value', ''))
        print(project_name + '\t\t\t\t' + device_name + '\t\t\t\t' +
              device_id + '\t\t\t\t' + variable_name + '\t\t\t\t' +
              temperature_value + '\t\t\t\t' + time_stamp)


def get_device_data(device_id, api_key, startid, stream_http, point_http,
                    stream_id):
    # This function retrieves data_dict from the device.
    #project_name:项目名称,variable_name:变量名称,device_id:设备ID,data_points:数据信息,device_name:设备名称,excel_path:excel名称及路径,sheet_name:sheet名(形参下同)

    request_payload = {'start': startid, 'limit': 6000}
    request_headers = {'api_key-key': api_key}
    stream_url = stream_http + device_id
    title_response = requests.get(stream_url, request_headers=request_headers)
    temp_str = str(title_response.text)
    temp_json = json.loads(temp_str)
    data_dict = temp_json['data_dict']
    data_streams = data_dict['data_streams']
    for index, values in enumerate(data_streams):
        device_name = values.get('device_name', '')

    point_url = point_http + device_id + "/datapoints?stream_id=" + stream_id
    point_response = requests.get(point_url,
                                  request_headers=request_headers,
                                  params=request_payload)
    temp_str = str(point_response.text)
    temp_json = json.loads(temp_str)
    data_dict = temp_json['data_dict']
    data_streams = data_dict['data_streams']
    for index, values in enumerate(data_streams):
        data_points = values.get('datapoints', '')
    return [device_name, data_points]


def read_config(config_filename):
    # This function reads the configuration file and returns the configuration parameters.
    current_path = os.path.dirname(os.path.realpath(__file__))
    config_path = os.path.join(current_path, config_filename)
    config_parser = configparser.ConfigParser()
    config_parser.read(config_path, encoding="utf-8")
    config_sections = config_parser.config_sections()
    config_items = config_parser.config_items('current_config')
    project_id = config_items[0][1]
    variable = config_items[1][1]
    device_id = config_items[2][1]
    api_key = config_items[3][1]
    start_id = config_items[4][1]
    excel_path = config_items[5][1]
    sheet_name = config_items[6][1]
    stream_http = config_items[7][1]
    point_http = config_items[8][1]
    return [
        project_id, variable, device_id, api_key, start_id, excel_path,
        sheet_name, stream_http, point_http
    ]


if __name__ == '__main__':
    application = QApplication(sys.argv)

    app_instance = MainApp()

    sys.exit(application.exec_())
