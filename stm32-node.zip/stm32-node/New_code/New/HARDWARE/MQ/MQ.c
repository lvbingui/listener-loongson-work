#include "MQ.h"
//#include "adc.h"
#include "delay.h"


#define CAL_PPM  10  // Ð£×¼»·¾³ÖÐPPMÖµ
#define RL	     10  // RL
#define R0	     26  // R0
#define SMOG_READ_TIMES	10
void MQ_Init(void)
{
 
 GPIO_InitTypeDef  GPIO_InitStructure;
 	
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD|RCC_APB2Periph_ADC1, ENABLE);	 //Ê¹ÄÜPD¶Ë¿ÚÊ±ÖÓ ADC1
 RCC_ADCCLKConfig(RCC_PCLK2_Div6);   //·ÖÆµÒò×Ó6Ê±ÖÓÎª72M/6=12MHz
	
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;				 //LED0-->PB.5 ¶Ë¿ÚÅäÖÃ
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN; 		 //ÍÆÍìÊä³ö
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO¿ÚËÙ¶ÈÎª50MHz
 GPIO_Init(GPIOD, &GPIO_InitStructure);					 //¸ù¾ÝÉè¶¨²ÎÊý³õÊ¼»¯GPIOB.5
 
	ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_55Cycles5);
	
		/* ADC1 ÅäÖÃ****************************************************************/
	ADC_InitTypeDef       ADC_InitStructure;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;	//Êý¾Ý¶ÔÆë
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None; //´¥·¢Ô´
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;		//
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;				//		
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;			//Á¬Ðø×ª»»
	ADC_InitStructure.ADC_NbrOfChannel = 1;		//Ò»¸öÍ¨µÀ
	ADC_Init(ADC1, &ADC_InitStructure);
	
		/* Ê¹ÄÜADC1 */
	ADC_Cmd(ADC1, ENABLE);
	
	//Ð£×¼
	ADC_ResetCalibration(ADC1);
	while (ADC_GetResetCalibrationStatus(ADC1) == SET);
	ADC_StartCalibration(ADC1);
	while (ADC_GetCalibrationStatus (ADC1) == SET);
	

}

uint16_t MQ2_ADC_Read(void)
{
	/* ???????? */ 
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);
	
	//??????
	while( ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
	
	return ADC_GetConversionValue(ADC1);
}


//?????
//u16 ADC1_Average_Data(u8 ADC_Channel)
//{
//	u16 temp_val=0;
//	u8 t;
//	for(t=0;t<SMOG_READ_TIMES;t++)	//#define SMOG_READ_TIMES	10	???????????,?????,??????
// 
//	{
//		temp_val+=MQ2_ADC_Read();	//??ADC?
//		delay_ms(5);
//	}
//	temp_val/=SMOG_READ_TIMES;//?????
//    return (u16)temp_val;//?????ADC???
//}
 
//??MQ7???????
float Smog_Get_Vol(void)
{
	uint16_t adc_value = 0;//´ÓMQ´«¸ÐÆ÷¶Áµ½µÄÖµ 0-4095
	float voltage = 0;//MQ µçÑ¹Êä³ö
	
	adc_value = MQ2_ADC_Read;//#define SMOG_ADC_CHX	ADC_Channel_4	??????????ADC????
	delay_ms(5);
	
  voltage  = (3.3/4096.0)*(adc_value);
	
	return voltage;
}
/*********************
// ???????,??????PPM?????RS???,???R0??
// ??????????R0?26
float MQ7_PPM_Calibration()
{
	float RS = 0;
	float R0 = 0;
	RS = (3.3f - Smog_Get_Vol()) / Smog_Get_Vol() * RL;//RL	10  // RL??
	R0 = RS / pow(CAL_PPM / 98.322, 1 / -1.458f);//CAL_PPM  10  // ?????PPM?
	return R0;
}
**********************/
 
// ??Smog_ppm
//float Smog_GetPPM()
//{
//	float RS = (3.3f - Smog_Get_Vol()) / Smog_Get_Vol() * RL;
//	float ppm = 98.322f * pow(RS/R0, -1.458f);
//	return  ppm;
//}


