#ifndef __MQ_H
#define __MQ_H	
#include "stm32f10x.h"

void MQ_Init(void);
uint16_t MQ2_ADC_Read(void);
float Smog_Get_Vol(void);


			    
#endif