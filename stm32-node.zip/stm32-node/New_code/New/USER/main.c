#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "usart3.h"
#include "esp8266.h"
#include "timer.h"
#include "dht11.h"
//#include "lcd.h"
#include "lsens.h"
#include "adc.h"
#include "OLED.h"
#include "MQ.h"
#include "CountSensor.h"

int main(void)
{
    u8 tempValue = 0;
    u8 humidity = 0;
    u8 t = 0;
		u8 adcx = 0;
		//u16 lightValue = 0;
		u16 ledctr = 0 ;
		u16 led0pwmval = 0;
		u8 SmogValue=0;
	  u16 counter = 0;

    // 设置中断优先级分组为组2：2位抢占优先级，2位响应优先级
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    delay_init();	   //延时函数初始化
    uart_init(115200); //串口初始化为115200

    LED_Init();
		OLED_Init();
        
    // 初始化ESP8266, 连接onenet, 进入透传模式
    uart3_init(115200);
    esp8266_start_trans();

    DHT11_Init();
		Lsens_Init();
		MQ_Init();
		CountSensor_Init();

	//LCD_Init();		
    //LCD_ShowString(30,50,200,16,16,"information collection system");
	
		TIM3_PWM_Init(1799,0);    //ARR=1799  不分频
	
    while (1)
    {
        DHT11_Read_Data(&tempValue,&humidity);	// 读取温湿度值
				OLED_ShowString(1, 1, "light:");
				OLED_ShowString(2, 1, "temp:");
				OLED_ShowString(3, 1, "humi:");
				OLED_ShowString(4, 1, "Smog:");	
			
        if (t == 10){
            t = 0;
			
						adcx = Lsens_Get_Val();   //读取光照信息：光照信息采集值赋给定义的adcx变量
						//将光照信息上传到云平台
						numToString(adcx);
						printf("lightValue: %s, ", strValue);
						OLED_ShowString(1, 8, strValue);
						OLED_ShowString(1, 11, "Lux");
						esp8266_str_data("light", strValue);   //onenet上的数据流名称：light
            
			// 将温度和湿度上传到云平台
            numToString(tempValue);
            printf("tempValue: %s, ", strValue);
			//LCD_ShowString(30,90,200,16,16,(u8 *)strValue);    //注意：定义为u8 *p指针类型，需要强制转换
			OLED_ShowString(2, 7, strValue);
			OLED_ShowChar(2, 10, 'C');
            esp8266_str_data("temp", strValue);

            numToString(humidity);
            printf("humidity: %s, ", strValue);
		    //LCD_ShowString(30,130,200,16,16,(u8 *)strValue);
			OLED_ShowString(3, 7, strValue);
			OLED_ShowChar(3, 10, '%');
            esp8266_str_data("humi", strValue);
						
						
						//将烟雾电压值读取、显示、上传至云平台
			SmogValue= MQ_Get_Val();
			numToString(SmogValue);
			printf("SmogValue: %s, ", strValue);
			OLED_ShowString(4, 7, strValue);	
//			OLED_ShowNum(4,7,SmogValue,1);
//			OLED_ShowChar(4, 8, '.');
//      OLED_ShowNum(4,9, (u8) (SmogValue * 100) % 100,2);
			//OLED_ShowChar(4, 12, 'V');
			esp8266_str_data("Smog",strValue);
			
			
// 将计数信息上传到云平台
						counter = CountSensor_Get();
						numToString(counter);
						printf("counter: %s\r\n\r\n", strValue);
						OLED_ShowNum(4,14,counter,1);
						esp8266_str_data("Counter",strValue);


//			//光照传感器控制LED1亮灭
//			lightValue = esp8266_get_data("light");     //OneNet中数据流light
//			if(lightValue < 20)
//			{
//				//LED0 = 0;
//				LED1 = 0;
//			}
//			else
//			{
//				//LED0 = 1;
//				LED1 = 1;
//			}
			
			//云平台控制LED1亮灭
			ledctr = esp8266_get_data("ledbtn");    //OneNet中数据流ledbtn
			if(ledctr == 1)    //ledbtn等于1：开启灯；0：关闭灯
			{
				//LED0 = 0;
				LED1 = 0;
			}
			else
			{
				//LED0 = 1;
				LED1 = 1;
			}
			
			//云平台旋钮控制呼吸灯LED0  PB5
			led0pwmval = esp8266_get_data("ledpwm");
			TIM_SetCompare2(TIM3,led0pwmval);		             //led0pwmval    PB5对应LED0
			
		    //LED_shan();
			
		}
		delay_ms(10);
		t++;
	}
}


